package com.riz.biodata;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;


public class MainActivity extends AppCompatActivity {
    CardView dialCard;
    String wrongNumber = "+6281312204790";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dialCard = findViewById(R.id.dial_card);
        dialCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent dialIntent = new Intent(Intent.ACTION_DIAL);
                dialIntent.setData(Uri.parse("tel:"+wrongNumber));
                startActivity(dialIntent);
            }
        });
    }

    public void alamat(View view) {
        String uri = "https://www.google.com/maps/place/7%C2%B006'28.4%22S+110%C2%B015'53.6%22E/@-7.10788,110.2643418,19z/data=!3m1!4b1!4m6!3m5!1s0x0:0x531d5d348414d066!7e2!8m2!3d-7.1078798!4d110.2648886";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
        startActivity(intent);
    }

    public void Email(View view) {
        Intent intent=new Intent(Intent.ACTION_SEND);
        String[] recipients={"111202113464@mhs.dinus.ac.id"};
        intent.putExtra(Intent.EXTRA_EMAIL, recipients);
        intent.putExtra(Intent.EXTRA_SUBJECT,"Subject text here...");
        intent.putExtra(Intent.EXTRA_TEXT,"Body of the content here...");
        intent.putExtra(Intent.EXTRA_CC,"mailcc@gmail.com");
        intent.setType("text/html");
        intent.setPackage("com.google.android.gm");
        startActivity(Intent.createChooser(intent, "Send mail"));
    }
}
